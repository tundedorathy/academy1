<?php
// Database configuration
$host = "localhost";
$dbname = "academy";
$user = "root";
$password = "";

$flutterwaveSecretKey = 'FLWSECK_TEST-dc46d140ae1adab3bdb986b1cfa654ad-X'; // Replace with your secret key

try {
    // Get the transaction reference from the URL
    if (!isset($_GET['tx_ref'])) {
        throw new Exception("Missing transaction reference.");
    }

    $tx_ref = $_GET['tx_ref'];

    // Initialize cURL to verify transaction
    $verifyUrl = "https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref={$tx_ref}";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $verifyUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $flutterwaveSecretKey"
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);

    if (!isset($result['status']) || $result['status'] !== 'success') {
        throw new Exception("Transaction verification failed.");
    }

    $data = $result['data'];
    $status = $data['status'];
    $amountPaid = $data['amount'];
    $currency = $data['currency'];

    if ($status === 'successful' && $data['tx_ref'] === $tx_ref) {
        // Connect to database
        $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Optional: Update user record as "paid"
        $stmt = $pdo->prepare("UPDATE users SET payment_status = 'paid' WHERE tx_ref = :tx_ref");
        $stmt->execute([':tx_ref' => $tx_ref]);

        echo "<h2>Payment Successful</h2>";
        echo "<p>Thank you for your payment. Your registration is now complete.</p>";
    } else {
        throw new Exception("Payment not successful or tx_ref mismatch.");
    }

} catch (Exception $e) {
    echo "<h2>Payment Failed</h2>";
    echo "<p>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
