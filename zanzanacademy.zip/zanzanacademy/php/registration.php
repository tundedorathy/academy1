<?php
// Database configuration
$host = "localhost";
$dbname = "academy";
$user = "root";
$password = "";

try {
    // Create a PDO instance
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Collect form data
    $fullName = trim($_POST['fullName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $selectedProgram = trim($_POST['selectedProgram'] ?? '');
    $paymentPlan = trim($_POST['paymentPlan'] ?? '');
    $currency = trim($_POST['currency'] ?? '');
    $referralCode = trim($_POST['referralCode'] ?? '');
    $termsAgreement = isset($_POST['termsAgreement']) ? 1 : 0;

    // Basic validation
    if (empty($fullName) || empty($email)) {
        throw new Exception("Full name and email are required.");
    }

    // Function to generate a unique referral code
    function generateReferralCode($length = 8)
    {
        return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, $length));
    }

    // Ensure the referral code is unique
    do {
        $ownReferralCode = generateReferralCode();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE ownReferralCode = :code");
        $stmt->execute([':code' => $ownReferralCode]);
        $codeExists = $stmt->fetchColumn() > 0;
    } while ($codeExists);

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Determine amount based on plan and currency
    if ($currency === 'NGN') {
        $amount = $paymentPlan === 'bundle' ? 250000 : 10;
    } else {
        $amount = $paymentPlan === 'bundle' ? 175 : 35;
    }

    // Generate unique reference
    $tx_ref = uniqid("TX_");

    // Save data to DB
    $sql = "INSERT INTO users 
        (fullName, email, password, phone, country, city, selectedProgram, paymentPlan, currency, termsAgreement, tx_ref, amount, ownReferralCode) 
        VALUES 
        (:fullName, :email, :password, :phone, :country, :city, :selectedProgram, :paymentPlan, :currency, :termsAgreement, :tx_ref, :amount, :ownReferralCode)";

    // Get ID of the newly registered user
    $newUserId = $pdo->lastInsertId();

    if (!empty($referralCode)) {
        // Find the referrer by their ownReferralCode
        $stmt = $pdo->prepare("SELECT id FROM users WHERE ownReferralCode = :refCode");
        $stmt->execute([':refCode' => $referralCode]);
        $referrer = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($referrer) {
            $referrerId = $referrer['id'];
            $rewardAmount = $amount * 0.10; // 10% reward

            // Insert referral earnings record
            $stmt = $pdo->prepare("INSERT INTO referral_earnings (referrer_id, referred_user_id, amount_earned) VALUES (:referrer_id, :referred_user_id, :amount_earned)");
            $stmt->execute([
                ':referrer_id' => $referrerId,
                ':referred_user_id' => $newUserId,
                ':amount_earned' => $rewardAmount
            ]);
        }
    }


    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':fullName' => $fullName,
        ':email' => $email,
        ':password' => $hashedPassword,
        ':phone' => $phone,
        ':country' => $country,
        ':city' => $city,
        ':selectedProgram' => $selectedProgram,
        ':paymentPlan' => $paymentPlan,
        ':currency' => $currency,
        ':termsAgreement' => $termsAgreement,
        ':tx_ref' => $tx_ref,
        ':amount' => $amount,
        ':ownReferralCode' => $ownReferralCode,
    ]);

    // FLUTTERWAVE INITIATION
    $flutterwaveSecretKey = 'FLWSECK_TEST-dc46d140ae1adab3bdb986b1cfa654ad-X'; // Flutterwave Secret Key
    $callbackURL = 'localhost/zanzanacademy/payment-callback.php'; // Callback url for confirmation of payment.
    $paymentData = [
        'tx_ref' => $tx_ref,
        'amount' => $amount,
        'currency' => $currency,
        'redirect_url' => $callbackURL,
        'customer' => [
            'email' => $email,
            'phonenumber' => $phone,
            'name' => $fullName,
        ],
        'customizations' => [
            'title' => 'Academy Program Payment',
            'description' => $selectedProgram,
        ]
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.flutterwave.com/v3/payments');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $flutterwaveSecretKey",
        "Content-Type: application/json"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($paymentData));

    $response = curl_exec($ch);
    $result = json_decode($response, true);

    if (isset($result['status']) && $result['status'] === 'success') {
        $paymentLink = $result['data']['link'];
        header("Location: $paymentLink");
        exit();
    } else {
        throw new Exception("Payment initiation failed: " . json_encode($result));
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
