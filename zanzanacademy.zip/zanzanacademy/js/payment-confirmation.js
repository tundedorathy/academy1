document.addEventListener("DOMContentLoaded", () => {
  // Get transaction data from sessionStorage or URL parameters
  const transactionData = getTransactionData()

  // Populate the page with transaction details
  populateTransactionDetails(transactionData)

  // Set up event listeners for buttons
  setupEventListeners()

  // Update the current year in the footer
  updateCurrentYear()
})

// Function to get transaction data from sessionStorage or URL parameters
function getTransactionData() {
  // Try to get data from sessionStorage first (set during payment process)
  const storedData = sessionStorage.getItem("transactionData")

  if (storedData) {
    try {
      return JSON.parse(storedData)
    } catch (e) {
      console.error("Error parsing stored transaction data:", e)
    }
  }

  // If no stored data, try to get from URL parameters
  const urlParams = new URLSearchParams(window.location.search)
  const registrationData = sessionStorage.getItem("registrationData")
  let userData = {}

  if (registrationData) {
    try {
      userData = JSON.parse(registrationData)
    } catch (e) {
      console.error("Error parsing stored registration data:", e)
    }
  }

  // Create a default transaction object with data from URL or defaults
  return {
    transactionId: urlParams.get("tx_ref") || "ZZA-" + generateRandomId(),
    date: new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
    paymentMethod: urlParams.get("payment_method") || "Card Payment",
    amount: urlParams.get("amount") || "₦50,000",
    program: userData.selectedProgram || urlParams.get("program") || "Digital Creativity & Social Media Economy",
    email: userData.email || urlParams.get("email") || "your@email.com",
    startDate: getStartDate(),
  }
}

// Function to populate the page with transaction details
function populateTransactionDetails(data) {
  // Transaction details
  document.getElementById("transactionId").textContent = data.transactionId
  document.getElementById("transactionDate").textContent = data.date
  document.getElementById("paymentMethod").textContent = data.paymentMethod
  document.getElementById("amountPaid").textContent = data.amount

  // Program details
  document.getElementById("programName").textContent = data.program
  document.getElementById("programImage").src = `images/program-${getProgramImageNumber(data.program)}.jpg`
  document.getElementById("programImage").alt = data.program

  // User details
  document.getElementById("userEmail").textContent = data.email
  document.getElementById("startDate").textContent = data.startDate
}

// Function to set up event listeners for buttons
function setupEventListeners() {
  // Download receipt button
// Update the setupEventListeners function in payment-confirmation.js
// Replace the existing downloadReceiptBtn event listener with this code:

// Download receipt button
const downloadReceiptBtn = document.getElementById("downloadReceipt")
if (downloadReceiptBtn) {
  downloadReceiptBtn.addEventListener("click", () => {
    // Get the transaction data
    const transactionData = getTransactionDataForReceipt()

    // Generate and download the PDF receipt
    try {
      const filename = window.ReceiptGenerator.generateReceipt(transactionData)

      // Show success message
      const successMessage = document.createElement("div")
      successMessage.className = "receipt-success-message"
      successMessage.innerHTML = `
        <div class="success-icon-small">
          <i class="icon-check"></i>
        </div>
        <span>Receipt downloaded: ${filename}</span>
      `

      // Add the message near the button
      downloadReceiptBtn.parentNode.appendChild(successMessage)

      // Remove the message after 5 seconds
      setTimeout(() => {
        if (successMessage.parentNode) {
          successMessage.parentNode.removeChild(successMessage)
        }
      }, 5000)
    } catch (error) {
      console.error("Error generating receipt:", error)
      alert("There was an error generating your receipt. Please try again or contact support.")
    }
  })
}

// Add this new function to payment-confirmation.js
// Function to get transaction data formatted for the receipt
function getTransactionDataForReceipt() {
  // Get the displayed transaction data from the DOM
  const transactionId = document.getElementById("transactionId").textContent
  const date = document.getElementById("transactionDate").textContent
  const paymentMethod = document.getElementById("paymentMethod").textContent
  const amount = document.getElementById("amountPaid").textContent
  const program = document.getElementById("programName").textContent
  const email = document.getElementById("userEmail").textContent
  const startDate = document.getElementById("startDate").textContent

  // Try to get the user's name from sessionStorage if available
  let name = ""
  const registrationData = sessionStorage.getItem("registrationData")
  if (registrationData) {
    try {
      const userData = JSON.parse(registrationData)
      name = userData.fullName || userData.name || ""
    } catch (e) {
      console.error("Error parsing registration data:", e)
    }
  }

  // Return the formatted data
  return {
    transactionId,
    date,
    paymentMethod,
    amount,
    program,
    email,
    name,
    startDate,
  }
}

  // Print receipt button
  const printReceiptBtn = document.getElementById("printReceipt")
  if (printReceiptBtn) {
    printReceiptBtn.addEventListener("click", () => {
      window.print()
    })
  }

  // Access dashboard button
  const accessDashboardBtn = document.getElementById("accessDashboard")
  if (accessDashboardBtn) {
    accessDashboardBtn.addEventListener("click", () => {
      alert("In a complete implementation, this would redirect to your learning dashboard.")
      // In a real implementation, this would redirect to the learning dashboard
      // window.location.href = 'dashboard.html';
    })
  }

  // Social share buttons
  const socialButtons = document.querySelectorAll(".social-share-btn")
  socialButtons.forEach((button) => {
    button.addEventListener("click", (e) => {
      e.preventDefault()

      const program = document.getElementById("programName").textContent
      const shareText = `I just enrolled in the ${program} program at Zanzan Academy! Excited to start my learning journey! #ZanzanAcademy #DigitalSkills`
      const shareUrl = window.location.origin

      let shareWindow

      if (button.classList.contains("facebook")) {
        shareWindow = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`
      } else if (button.classList.contains("twitter")) {
        shareWindow = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`
      } else if (button.classList.contains("linkedin")) {
        shareWindow = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`
      } else if (button.classList.contains("whatsapp")) {
        shareWindow = `https://wa.me/?text=${encodeURIComponent(shareText + " " + shareUrl)}`
      }

      if (shareWindow) {
        window.open(shareWindow, "_blank", "width=600,height=400")
      }
    })
  })

  // Mobile menu button
  const mobileMenuBtn = document.getElementById("mobileMenuBtn")
  const mobileMenu = document.getElementById("mobileMenu")

  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener("click", () => {
      mobileMenuBtn.classList.toggle("active")
      mobileMenu.classList.toggle("active")
    })
  }
}

// Function to get program image number based on program name
function getProgramImageNumber(programName) {
  const programMap = {
    "Digital Creativity & Social Media Economy": 1,
    "Entrepreneurship and Business Development": 2,
    "Digital Marketing & Professional Online Services": 3,
    "Professional Writing, Publishing & Copyright Literacy": 4,
    "Corporate Tech Skills, Digital Business Administration and Cybersecurity Education": 5,
    "Artificial Intelligence Literacy": 6,
    "Leadership and Career Development": 7,
  }

  return programMap[programName] || 1
}

// Function to generate a random transaction ID
function generateRandomId() {
  return (
    Math.random().toString(36).substring(2, 8).toUpperCase() + Math.random().toString(36).substring(2, 8).toUpperCase()
  )
}

// Function to get the start date (next Monday)
function getStartDate() {
  const today = new Date()
  const nextMonday = new Date()
  nextMonday.setDate(today.getDate() + ((7 - today.getDay() + 1) % 7 || 7))

  return nextMonday.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

// Function to update the current year in the footer
function updateCurrentYear() {
  const currentYearElement = document.getElementById("currentYear")
  if (currentYearElement) {
    currentYearElement.textContent = new Date().getFullYear()
  }
}
