// PDF Receipt Generator for Zanzan Academy
// This file handles the generation and downloading of PDF receipts

// Define the PDF generation functionality in a separate module
const ReceiptGenerator = {
  // Generate and download a PDF receipt
  generateReceipt: function (transactionData) {
    // Import jsPDF from the global scope
    const { jsPDF } = window.jspdf

    // Create a new PDF document
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a4",
    })

    // Set document properties
    doc.setProperties({
      title: "Zanzan Academy - Payment Receipt",
      subject: "Payment Receipt",
      author: "Zanzan Academy",
      keywords: "receipt, payment, zanzan academy",
      creator: "Zanzan Academy Receipt System",
    })

    // Add Zanzan Academy branding
    this.addBranding(doc)

    // Add receipt header
    this.addReceiptHeader(doc, transactionData)

    // Add customer information
    this.addCustomerInfo(doc, transactionData)

    // Add transaction details
    this.addTransactionDetails(doc, transactionData)

    // Add program details
    this.addProgramDetails(doc, transactionData)

    // Add payment summary
    this.addPaymentSummary(doc, transactionData)

    // Add footer with terms and contact information
    this.addFooter(doc)

    // Save the PDF with a descriptive filename
    const filename = `Zanzan_Academy_Receipt_${transactionData.transactionId}.pdf`
    doc.save(filename)

    return filename
  },

  // Add Zanzan Academy branding to the PDF
  addBranding: (doc) => {
    // Set colors based on Zanzan Academy branding
    const primaryColor = [0, 128, 128] // Teal color in RGB
    const secondaryColor = [70, 70, 70] // Dark gray in RGB

    // Add colored header bar
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2])
    doc.rect(0, 0, 210, 25, "F")

    // Add title
    doc.setFont("helvetica", "bold")
    doc.setTextColor(255, 255, 255) // White text
    doc.setFontSize(20)
    doc.text("PAYMENT RECEIPT", 105, 15, { align: "center" })

    // Add logo placeholder (in a real implementation, you would add the actual logo)
    doc.setFillColor(255, 255, 255)
    doc.roundedRect(15, 10, 30, 15, 2, 2, "F")
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2])
    doc.setFontSize(10)
    doc.text("ZANZAN", 30, 17, { align: "center" })
    doc.text("ACADEMY", 30, 22, { align: "center" })
  },

  // Add receipt header with receipt number and date
  addReceiptHeader: (doc, data) => {
    doc.setFont("helvetica", "normal")
    doc.setTextColor(70, 70, 70)
    doc.setFontSize(10)

    // Add receipt information
    doc.text(`Receipt Number: ${data.transactionId}`, 15, 35)
    doc.text(`Date: ${data.date}`, 15, 40)

    // Add "OFFICIAL RECEIPT" watermark
    doc.setFont("helvetica", "bold")
    doc.setTextColor(230, 230, 230)
    doc.setFontSize(60)
    doc.text("OFFICIAL RECEIPT", 105, 120, {
      align: "center",
      angle: 45,
    })

    // Reset text color
    doc.setTextColor(70, 70, 70)
    doc.setFontSize(10)
    doc.setFont("helvetica", "normal")
  },

  // Add customer information
  addCustomerInfo: (doc, data) => {
    doc.setFillColor(240, 240, 240)
    doc.rect(15, 45, 180, 25, "F")

    doc.setFont("helvetica", "bold")
    doc.setFontSize(11)
    doc.text("CUSTOMER INFORMATION", 20, 52)

    doc.setFont("helvetica", "normal")
    doc.setFontSize(10)

    // In a real implementation, you would include more customer details
    // For now, we'll just use the email from the transaction data
    doc.text(`Email: ${data.email}`, 20, 60)
    doc.text(`Name: ${data.name || "Student"}`, 20, 65)
  },

  // Add transaction details
  addTransactionDetails: (doc, data) => {
    doc.setFont("helvetica", "bold")
    doc.setFontSize(11)
    doc.text("TRANSACTION DETAILS", 15, 80)

    doc.setFont("helvetica", "normal")
    doc.setFontSize(10)

    // Create a table for transaction details
    const tableColumn = ["Description", "Details"]
    const tableRows = [
      ["Transaction ID", data.transactionId],
      ["Transaction Date", data.date],
      ["Payment Method", data.paymentMethod],
      ["Status", "Completed"],
    ]

    doc.autoTable({
      startY: 85,
      head: [tableColumn],
      body: tableRows,
      theme: "grid",
      headStyles: {
        fillColor: [0, 128, 128],
        textColor: [255, 255, 255],
        fontStyle: "bold",
      },
      styles: {
        lineColor: [220, 220, 220],
      },
      margin: { left: 15, right: 15 },
    })
  },

  // Add program details
  addProgramDetails: (doc, data) => {
    const finalY = doc.lastAutoTable.finalY + 10

    doc.setFont("helvetica", "bold")
    doc.setFontSize(11)
    doc.text("PROGRAM DETAILS", 15, finalY)

    doc.setFont("helvetica", "normal")
    doc.setFontSize(10)

    // Create a table for program details
    const tableColumn = ["Program", "Description", "Start Date"]
    const tableRows = [[data.program, "Comprehensive training program", data.startDate]]

    doc.autoTable({
      startY: finalY + 5,
      head: [tableColumn],
      body: tableRows,
      theme: "grid",
      headStyles: {
        fillColor: [0, 128, 128],
        textColor: [255, 255, 255],
        fontStyle: "bold",
      },
      styles: {
        lineColor: [220, 220, 220],
      },
      margin: { left: 15, right: 15 },
    })
  },

  // Add payment summary
  addPaymentSummary: (doc, data) => {
    const finalY = doc.lastAutoTable.finalY + 10

    doc.setFont("helvetica", "bold")
    doc.setFontSize(11)
    doc.text("PAYMENT SUMMARY", 15, finalY)

    // Parse the amount to get the currency and value
    let currency = "₦"
    let amount = "50,000"

    if (data.amount) {
      if (data.amount.includes("₦")) {
        const parts = data.amount.split("₦")
        amount = parts[1] || amount
      } else if (data.amount.includes("$")) {
        currency = "$"
        const parts = data.amount.split("$")
        amount = parts[1] || amount
      } else {
        amount = data.amount
      }
    }

    // Create a table for payment summary
    const tableColumn = ["Item", "Amount"]
    const tableRows = [
      ["Program Fee", `${currency}${amount}`],
      ["Discount", `${currency}0.00`],
      ["Total Paid", `${currency}${amount}`],
    ]

    doc.autoTable({
      startY: finalY + 5,
      head: [tableColumn],
      body: tableRows,
      theme: "grid",
      headStyles: {
        fillColor: [0, 128, 128],
        textColor: [255, 255, 255],
        fontStyle: "bold",
      },
      styles: {
        lineColor: [220, 220, 220],
      },
      margin: { left: 15, right: 15 },
      foot: [["Total Amount Paid", `${currency}${amount}`]],
      footStyles: {
        fillColor: [240, 240, 240],
        textColor: [0, 0, 0],
        fontStyle: "bold",
      },
    })
  },

  // Add footer with terms and contact information
  addFooter: (doc) => {
    const finalY = doc.lastAutoTable.finalY + 15

    // Add thank you message
    doc.setFont("helvetica", "bold")
    doc.setFontSize(11)
    doc.text("Thank you for choosing Zanzan Academy!", 105, finalY, { align: "center" })

    // Add terms and conditions
    doc.setFont("helvetica", "normal")
    doc.setFontSize(8)
    doc.text("This receipt serves as proof of payment. Please keep it for your records.", 105, finalY + 7, {
      align: "center",
    })
    doc.text("For any questions or concerns, please contact our support team.", 105, finalY + 12, { align: "center" })

    // Add contact information
    doc.text(
      "Email: support@zanzanacademy.com | Phone: +123-456-7890 | Website: www.zanzanacademy.com",
      105,
      finalY + 17,
      { align: "center" },
    )

    // Add page number
    doc.setFontSize(8)
    doc.text(`Page 1 of 1`, 195, 287, { align: "right" })

    // Add colored footer bar
    doc.setFillColor(0, 128, 128)
    doc.rect(0, 290, 210, 7, "F")
  },
}

// Export the ReceiptGenerator object for use in other scripts
window.ReceiptGenerator = ReceiptGenerator
