document.addEventListener("DOMContentLoaded", () => {
  // Get URL parameters
  const urlParams = new URLSearchParams(window.location.search)
  const programParam = urlParams.get("program")
  const planParam = urlParams.get("plan")
  const currencyParam = urlParams.get("currency")

  // Form elements
  const form = document.getElementById("registrationForm")
  const steps = document.querySelectorAll(".form-step")
  const progressSteps = document.querySelectorAll(".progress-step")
  const nextButtons = document.querySelectorAll(".next-step")
  const prevButtons = document.querySelectorAll(".prev-step")
  const programSelect = document.getElementById("selectedProgram")
  const paymentPlanSelect = document.getElementById("paymentPlan")
  const currencyRadios = document.querySelectorAll('input[name="currency"]')
  const proceedButton = document.getElementById("proceedToPayment")

  // Sidebar elements
  const sidebarCourse = document.getElementById("sidebarCourse")
  const programFee = document.getElementById("programFee")
  const totalAmount = document.getElementById("totalAmount")

  // Review elements
  const reviewName = document.getElementById("reviewName")
  const reviewEmail = document.getElementById("reviewEmail")
  const reviewPhone = document.getElementById("reviewPhone")
  const reviewLocation = document.getElementById("reviewLocation")
  const reviewProgram = document.getElementById("reviewProgram")
  const reviewPaymentPlan = document.getElementById("reviewPaymentPlan")
  const reviewCurrency = document.getElementById("reviewCurrency")
  const reviewAmount = document.getElementById("reviewAmount")

  // Pre-fill form if URL parameters exist
  if (programParam) {
    // Find the option that matches the program parameter
    for (let i = 0; i < programSelect.options.length; i++) {
      if (programSelect.options[i].value === programParam) {
        programSelect.selectedIndex = i
        break
      }
    }
    updateSidebarCourse()
  }

  if (planParam) {
    for (let i = 0; i < paymentPlanSelect.options.length; i++) {
      if (paymentPlanSelect.options[i].value === planParam) {
        paymentPlanSelect.selectedIndex = i
        break
      }
    }
    updatePricing()
  }

  if (currencyParam) {
    currencyRadios.forEach((radio) => {
      if (radio.value === currencyParam) {
        radio.checked = true
      }
    })
    updatePricing()
  }

  // Navigation between steps
  nextButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const currentStep = this.closest(".form-step")
      const currentStepIndex = Array.from(steps).indexOf(currentStep)

      // Validate current step
      if (validateStep(currentStepIndex + 1)) {
        // Hide current step
        currentStep.classList.remove("active")
        // Show next step
        steps[currentStepIndex + 1].classList.add("active")
        // Update progress
        progressSteps[currentStepIndex].classList.add("completed")
        progressSteps[currentStepIndex + 1].classList.add("active")

        // If moving to review step, populate review data
        if (currentStepIndex + 2 === 3) {
          populateReviewData()
        }
      }
    })
  })

  prevButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const currentStep = this.closest(".form-step")
      const currentStepIndex = Array.from(steps).indexOf(currentStep)

      // Hide current step
      currentStep.classList.remove("active")
      // Show previous step
      steps[currentStepIndex - 1].classList.add("active")
      // Update progress
      progressSteps[currentStepIndex].classList.remove("active")
      progressSteps[currentStepIndex - 1].classList.remove("completed")
      progressSteps[currentStepIndex - 1].classList.add("active")
    })
  })

  // Form submission
  // form.addEventListener("submit", (e) => {
  //   e.preventDefault()

  //   // Validate final step
  //   if (!document.getElementById("termsAgreement").checked) {
  //     alert("Please agree to the Terms and Conditions to proceed.")
  //     return
  //   }

  //   // Collect form data
  //   const formData = new FormData(form)
  //   const formDataObj = {}
  //   formData.forEach((value, key) => {
  //     formDataObj[key] = value
  //   })

  //   // Store form data in session storage for the payment page
  //   sessionStorage.setItem("registrationData", JSON.stringify(formDataObj))

  //   // Redirect to Flutterwave payment page (this would be replaced with your actual implementation)
  //   alert("Form submitted successfully! You would now be redirected to the payment gateway.")
  //   // window.location.href = 'payment.html'; // Replace with your actual payment page

  //   // In a real implementation, you might want to submit this data to your server first
  //   // and then redirect to Flutterwave based on the server response
  // })

  // Update sidebar when program selection changes
  programSelect.addEventListener("change", updateSidebarCourse)
  paymentPlanSelect.addEventListener("change", updatePricing)

  currencyRadios.forEach((radio) => {
    radio.addEventListener("change", updatePricing)
  })

  // Function to validate each step
  function validateStep(stepNumber) {
    let isValid = true

    if (stepNumber === 1) {
      // Validate personal information
      const requiredFields = ["fullName", "email", "phone", "country", "city"]
      requiredFields.forEach((field) => {
        const input = document.getElementById(field)
        if (!input.value.trim()) {
          isValid = false
          input.classList.add("error")
        } else {
          input.classList.remove("error")
        }
      })

      // Validate email format
      const email = document.getElementById("email")
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!emailRegex.test(email.value)) {
        isValid = false
        email.classList.add("error")
        if (email.value.trim()) {
          alert("Please enter a valid email address.")
        }
      }

      if (!isValid) {
        alert("Please fill in all required fields correctly.")
      }
    } else if (stepNumber === 2) {
      // Validate course details
      if (!programSelect.value) {
        isValid = false
        programSelect.classList.add("error")
      } else {
        programSelect.classList.remove("error")
      }

      if (!paymentPlanSelect.value) {
        isValid = false
        paymentPlanSelect.classList.add("error")
      } else {
        paymentPlanSelect.classList.remove("error")
      }

      if (!isValid) {
        alert("Please select a program and payment plan.")
      }
    }

    return isValid
  }

  // Function to update sidebar course information
  function updateSidebarCourse() {
    const selectedProgram = programSelect.value

    if (selectedProgram) {
      // Create course card HTML
      const courseHTML = `
        <div class="course-card">
          <img src="images/program-${getProgramImageNumber(selectedProgram)}.jpg" alt="${selectedProgram}" class="course-image">
          <div class="course-card-content">
            <div class="course-card-title">${selectedProgram}</div>
            <div class="course-card-description">Comprehensive training program</div>
          </div>
        </div>
      `

      sidebarCourse.innerHTML = courseHTML
    } else {
      sidebarCourse.innerHTML = `
        <div class="course-placeholder">
          <p>Your selected course will appear here</p>
        </div>
      `
    }

    updatePricing()
  }

  // Function to get program image number based on program name
  function getProgramImageNumber(programName) {
    const programMap = {
      "Digital Creativity & Social Media Economy": 1,
      "Entrepreneurship and Business Development": 2,
      "Digital Marketing & Professional Online Services": 3,
      "Professional Writing, Publishing & Copyright Literacy": 4,
      "Corporate Tech Skills, Digital Business Administration and Cybersecurity Education": 5,
      "Artificial Intelligence Literacy": 6,
      "Leadership and Career Development": 7,
    }

    return programMap[programName] || 1
  }

  // Function to update pricing information
  function updatePricing() {
    const selectedPlan = paymentPlanSelect.value
    const selectedCurrency = document.querySelector('input[name="currency"]:checked').value

    let price = 0
    let currencySymbol = ""

    if (selectedCurrency === "NGN") {
      currencySymbol = "₦"
      price = selectedPlan === "bundle" ? 250000 : 50000
    } else {
      currencySymbol = "$"
      price = selectedPlan === "bundle" ? 175 : 35
    }

    programFee.textContent = `${currencySymbol}${price.toLocaleString()}`
    totalAmount.textContent = `${currencySymbol}${price.toLocaleString()}`
  }

  // Function to populate review data
  function populateReviewData() {
    // Personal information
    reviewName.textContent = document.getElementById("fullName").value
    reviewEmail.textContent = document.getElementById("email").value
    reviewPhone.textContent = document.getElementById("phone").value
    reviewLocation.textContent = `${document.getElementById("city").value}, ${document.getElementById("country").value}`

    // Course details
    reviewProgram.textContent = programSelect.options[programSelect.selectedIndex].text
    reviewPaymentPlan.textContent = paymentPlanSelect.options[paymentPlanSelect.selectedIndex].text

    const selectedCurrency = document.querySelector('input[name="currency"]:checked').value
    reviewCurrency.textContent = selectedCurrency === "NGN" ? "Nigerian Naira (₦)" : "US Dollar ($)"

    // Amount
    reviewAmount.textContent = totalAmount.textContent
  }

  // Initialize sidebar
  updateSidebarCourse()
})

// Function to update the current year in the footer
document.addEventListener("DOMContentLoaded", () => {
  const currentYearElement = document.getElementById("currentYear")
  if (currentYearElement) {
    currentYearElement.textContent = new Date().getFullYear()
  }
})
