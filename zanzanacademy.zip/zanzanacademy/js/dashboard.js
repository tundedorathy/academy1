document.addEventListener("DOMContentLoaded", () => {
  // Toggle sidebar
  const menuToggle = document.getElementById("menuToggle")
  const dashboardSidebar = document.getElementById("dashboardSidebar")

  if (menuToggle && dashboardSidebar) {
    menuToggle.addEventListener("click", () => {
      dashboardSidebar.classList.toggle("active")
    })
  }

  // User dropdown
  const userMenuButton = document.getElementById("userMenuButton")
  const userDropdown = document.getElementById("userDropdown")

  if (userMenuButton && userDropdown) {
    userMenuButton.addEventListener("click", (e) => {
      e.stopPropagation()
      userDropdown.classList.toggle("active")
    })

    // Close dropdown when clicking outside
    document.addEventListener("click", (e) => {
      if (userDropdown.classList.contains("active") && !userDropdown.contains(e.target)) {
        userDropdown.classList.remove("active")
      }
    })
  }

  // Simulate loading user data
  updateUserInfo({
    name: "John Doe",
    avatar: "images/avatar-placeholder.jpg",
    courses: [
      {
        id: 1,
        title: "Digital Creativity & Social Media Economy",
        cohort: "Spring 2023 - Group A",
        duration: "12 weeks (24 hours total)",
        startDate: "March 15, 2023",
        endDate: "June 7, 2023",
        payment: "$499 (Paid in Full)",
      },
      {
        id: 2,
        title: "Entrepreneurship and Business Development",
        cohort: "Winter 2023 - Group B",
        duration: "10 weeks (20 hours total)",
        startDate: "January 10, 2023",
        endDate: "March 21, 2023",
        payment: "$599 (Payment Plan: $199/month)",
      },
      {
        id: 3,
        title: "Artificial Intelligence Literacy",
        cohort: "Spring 2023 - Group C",
        duration: "8 weeks (16 hours total)",
        startDate: "April 5, 2023",
        endDate: "May 31, 2023",
        payment: "$399 (Bundle Discount Applied)",
      },
    ],
  })
})

// Update user information in the UI
function updateUserInfo(user) {
  // Update welcome message
  const welcomeHeading = document.querySelector(".welcome-content h1")
  if (welcomeHeading) {
    welcomeHeading.textContent = `Welcome back, ${user.name.split(" ")[0]}!`
  }

  // Update user name in header
  const userName = document.querySelector(".user-name")
  if (userName) {
    userName.textContent = user.name
  }

  // Update user avatar
  const userAvatars = document.querySelectorAll(".user-avatar img")
  userAvatars.forEach((avatar) => {
    avatar.src = user.avatar
    avatar.alt = user.name
  })
}
