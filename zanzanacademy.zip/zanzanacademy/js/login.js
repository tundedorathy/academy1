document.addEventListener("DOMContentLoaded", () => {
  // Toggle password visibility
  const togglePassword = document.getElementById("togglePassword")
  const passwordInput = document.getElementById("password")

  if (togglePassword && passwordInput) {
    togglePassword.addEventListener("click", function () {
      const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
      passwordInput.setAttribute("type", type)

      // Toggle eye icon
      const eyeIcon = this.querySelector("i")
      eyeIcon.classList.toggle("fa-eye")
      eyeIcon.classList.toggle("fa-eye-slash")
    })
  }

  // Form validation
  const loginForm = document.getElementById("loginForm")
  const emailInput = document.getElementById("email")
  const emailError = document.getElementById("emailError")
  const passwordError = document.getElementById("passwordError")

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault()

      let isValid = true

      // Reset error messages
      if (emailError) emailError.textContent = ""
      if (passwordError) passwordError.textContent = ""

      // Validate email
      if (emailInput && emailError) {
        if (!emailInput.value.trim()) {
          emailError.textContent = "Email is required"
          isValid = false
        } else if (!isValidEmail(emailInput.value.trim())) {
          emailError.textContent = "Please enter a valid email address"
          isValid = false
        }
      }

      // Validate password
      if (passwordInput && passwordError) {
        if (!passwordInput.value) {
          passwordError.textContent = "Password is required"
          isValid = false
        } else if (passwordInput.value.length < 6) {
          passwordError.textContent = "Password must be at least 6 characters"
          isValid = false
        }
      }

      // If form is valid, proceed with login
      if (isValid) {
        // For demo purposes, we'll redirect to the dashboard
        // In a real implementation, you would send the credentials to your server
        simulateLogin()
      }
    })
  }

  // Email validation helper
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  // Simulate login for demo purposes
  function simulateLogin() {
    // Show loading state
    const submitButton = loginForm.querySelector('button[type="submit"]')
    const originalText = submitButton.textContent
    submitButton.disabled = true
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...'

    // Simulate API call delay
    setTimeout(() => {
      // Redirect to dashboard
      window.location.href = "dashboard.html"
    }, 1500)
  }

  // Remember me functionality
  const rememberMeCheckbox = document.getElementById("rememberMe")

  // Check if we have saved credentials
  if (rememberMeCheckbox && emailInput && passwordInput) {
    const savedEmail = localStorage.getItem("zanzanEmail")
    const rememberMeStatus = localStorage.getItem("zanzanRememberMe")

    if (savedEmail && rememberMeStatus === "true") {
      emailInput.value = savedEmail
      rememberMeCheckbox.checked = true
    }

    // Save credentials if remember me is checked
    rememberMeCheckbox.addEventListener("change", function () {
      if (this.checked) {
        localStorage.setItem("zanzanRememberMe", "true")
        if (emailInput.value) {
          localStorage.setItem("zanzanEmail", emailInput.value)
        }
      } else {
        localStorage.removeItem("zanzanRememberMe")
        localStorage.removeItem("zanzanEmail")
      }
    })
  }
})
