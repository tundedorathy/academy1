document.addEventListener("DOMContentLoaded", () => {
  // Import CertificateGenerator (assuming it's in a separate module)
  // If it's not a module, you'll need to define it here.
  // Example using import:
  // import CertificateGenerator from './certificate-generator';

  // Example if CertificateGenerator is defined in the same file or globally:
  const CertificateGenerator = {
    generateCertificate: (certificateData) =>
      new Promise((resolve, reject) => {
        // Simulate PDF generation delay
        setTimeout(() => {
          console.log("Simulating PDF generation...")
          resolve("certificate.pdf") // Simulate successful download
        }, 1500)
      }),
    printCertificate: () => {
      window.print()
    },
  }

  // Certificate data - in a real implementation, this would come from an API
  const certificateData = {
    studentName: "John Doe",
    courseName: "Digital Creativity & Social Media Economy",
    issueDate: "June 7, 2023",
    certificateId: "ZA-DC-2023-06-1234",
    instructorName: "Dr. Sarah Williams",
    instructorTitle: "Program Director",
    hoursCompleted: 24,
  }

  // Download certificate button
  const downloadCertificateBtn = document.getElementById("downloadCertificate")
  if (downloadCertificateBtn) {
    downloadCertificateBtn.addEventListener("click", function () {
      // Show loading state
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating PDF...'
      this.disabled = true

      // Generate and download the certificate
      CertificateGenerator.generateCertificate(certificateData)
        .then((filename) => {
          console.log(`Certificate downloaded as ${filename}`)
          // Reset button state
          this.innerHTML = '<i class="fas fa-download"></i> Download Certificate'
          this.disabled = false

          // Show success message
          showNotification("Certificate downloaded successfully!", "success")
        })
        .catch((error) => {
          console.error("Failed to generate certificate:", error)
          // Reset button state
          this.innerHTML = '<i class="fas fa-download"></i> Download Certificate'
          this.disabled = false

          // Show error message
          showNotification("Failed to generate certificate. Please try again.", "error")
        })
    })
  }

  // Print certificate button
  const printCertificateBtn = document.getElementById("printCertificate")
  if (printCertificateBtn) {
    printCertificateBtn.addEventListener("click", () => {
      CertificateGenerator.printCertificate()
    })
  }

  // Share certificate button and modal
  const shareCertificateBtn = document.getElementById("shareCertificate")
  const shareModal = document.getElementById("shareModal")
  const closeModalBtn = document.querySelector(".close-modal")

  if (shareCertificateBtn && shareModal) {
    shareCertificateBtn.addEventListener("click", () => {
      shareModal.classList.add("active")
    })

    // Close modal when clicking the close button
    if (closeModalBtn) {
      closeModalBtn.addEventListener("click", () => {
        shareModal.classList.remove("active")
      })
    }

    // Close modal when clicking outside
    window.addEventListener("click", (e) => {
      if (e.target === shareModal) {
        shareModal.classList.remove("active")
      }
    })
  }

  // Copy certificate link
  const copyLinkBtn = document.getElementById("copyLink")
  const certificateLink = document.getElementById("certificateLink")

  if (copyLinkBtn && certificateLink) {
    copyLinkBtn.addEventListener("click", function () {
      certificateLink.select()
      document.execCommand("copy")

      // Show feedback
      this.textContent = "Copied!"
      setTimeout(() => {
        this.textContent = "Copy"
      }, 2000)
    })
  }

  // Share options
  const shareOptions = document.querySelectorAll(".share-option")

  shareOptions.forEach((option) => {
    option.addEventListener("click", function (e) {
      e.preventDefault()

      const platform = this.getAttribute("data-platform")
      const url = encodeURIComponent(certificateLink.value)
      const text = encodeURIComponent(`I've completed the ${certificateData.courseName} course at Zanzan Academy!`)

      let shareUrl = ""

      switch (platform) {
        case "linkedin":
          shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`
          break
        case "twitter":
          shareUrl = `https://twitter.com/intent/tweet?text=${text}&url=${url}`
          break
        case "facebook":
          shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`
          break
        case "email":
          shareUrl = `mailto:?subject=${encodeURIComponent("My Zanzan Academy Certificate")}&body=${text}%0A%0A${url}`
          break
      }

      if (shareUrl) {
        window.open(shareUrl, "_blank")
      }
    })
  })

  // Helper function to show notifications
  function showNotification(message, type = "info") {
    // Check if notification container exists, create if not
    let notificationContainer = document.querySelector(".notification-container")

    if (!notificationContainer) {
      notificationContainer = document.createElement("div")
      notificationContainer.className = "notification-container"
      document.body.appendChild(notificationContainer)

      // Add styles for the notification container
      const style = document.createElement("style")
      style.textContent = `
        .notification-container {
          position: fixed;
          top: 20px;
          right: 20px;
          z-index: 9999;
        }
        .notification {
          padding: 15px 20px;
          margin-bottom: 10px;
          border-radius: 4px;
          color: white;
          font-weight: 500;
          display: flex;
          align-items: center;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          animation: slideIn 0.3s ease-out forwards;
        }
        .notification.success {
          background-color: #10b981;
        }
        .notification.error {
          background-color: #ef4444;
        }
        .notification.info {
          background-color: #3b82f6;
        }
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes fadeOut {
          from { opacity: 1; }
          to { opacity: 0; }
        }
      `
      document.head.appendChild(style)
    }

    // Create notification element
    const notification = document.createElement("div")
    notification.className = `notification ${type}`
    notification.textContent = message

    // Add to container
    notificationContainer.appendChild(notification)

    // Remove after 3 seconds
    setTimeout(() => {
      notification.style.animation = "fadeOut 0.3s ease-out forwards"
      setTimeout(() => {
        notification.remove()
      }, 300)
    }, 3000)
  }
})
