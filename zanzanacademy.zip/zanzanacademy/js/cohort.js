// Cohort Tab Functionality
document.addEventListener("DOMContentLoaded", () => {
  // Get all cohort tabs and content
  const cohortTabs = document.querySelectorAll(".cohort-tab")
  const cohortContents = document.querySelectorAll(".cohort-content")

  // Add click event to each tab
  cohortTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      // Remove active class from all tabs and contents
      cohortTabs.forEach((t) => t.classList.remove("active"))
      cohortContents.forEach((c) => c.classList.remove("active"))

      // Add active class to clicked tab
      this.classList.add("active")

      // Get the tab data attribute and show corresponding content
      const tabId = this.getAttribute("data-tab")
      document.getElementById(`${tabId}-cohorts`).classList.add("active")
    })
  })

  // Animation for timeline items on scroll
  const timelineItems = document.querySelectorAll(".timeline-item")

  // Check if IntersectionObserver is supported
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate")
            observer.unobserve(entry.target)
          }
        })
      },
      { threshold: 0.2 },
    )

    timelineItems.forEach((item) => {
      item.style.opacity = "0"
      item.style.transform = "translateY(20px)"
      item.style.transition = "opacity 0.5s ease, transform 0.5s ease"
      observer.observe(item)
    })
  }

  // Add animation class for timeline items
  document.querySelectorAll(".timeline-item.animate").forEach((item) => {
    item.style.opacity = "1"
    item.style.transform = "translateY(0)"
  })
})
