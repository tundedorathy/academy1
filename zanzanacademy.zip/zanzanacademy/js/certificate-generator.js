// Certificate Generator for Zanzan Academy
// This file handles the generation and downloading of PDF certificates

// Define the certificate generator functionality
const CertificateGenerator = {
  // Generate and download a PDF certificate
  generateCertificate: (certificateData) => {
    // Import jsPDF from the global scope
    const { jsPDF } = window.jspdf

    return new Promise((resolve, reject) => {
      // Get the certificate element
      const certificateElement = document.getElementById("certificateElement")

      if (!certificateElement) {
        reject("Certificate element not found")
        return
      }

      // Use html2canvas to capture the certificate as an image
      html2canvas(certificateElement, {
        scale: 2, // Higher scale for better quality
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#ffffff",
      })
        .then((canvas) => {
          // Create a new PDF document in landscape orientation
          const pdf = new jsPDF({
            orientation: "landscape",
            unit: "mm",
            format: "a4",
          })

          // Set document properties
          pdf.setProperties({
            title: `${certificateData.courseName} Certificate - Zanzan Academy`,
            subject: "Course Completion Certificate",
            author: "Zanzan Academy",
            keywords: "certificate, course, completion, zanzan academy",
            creator: "Zanzan Academy Certificate System",
          })

          // Get the dimensions of the PDF page
          const pdfWidth = pdf.internal.pageSize.getWidth()
          const pdfHeight = pdf.internal.pageSize.getHeight()

          // Convert the canvas to an image
          const imgData = canvas.toDataURL("image/jpeg", 1.0)

          // Calculate the ratio to fit the image within the PDF
          const canvasRatio = canvas.width / canvas.height
          const pageRatio = pdfWidth / pdfHeight

          let imgWidth, imgHeight

          if (canvasRatio > pageRatio) {
            // If the image is wider than the page ratio
            imgWidth = pdfWidth
            imgHeight = pdfWidth / canvasRatio
          } else {
            // If the image is taller than the page ratio
            imgHeight = pdfHeight
            imgWidth = pdfHeight * canvasRatio
          }

          // Calculate position to center the image
          const x = (pdfWidth - imgWidth) / 2
          const y = (pdfHeight - imgHeight) / 2

          // Add the image to the PDF
          pdf.addImage(imgData, "JPEG", x, y, imgWidth, imgHeight)

          // Save the PDF with a descriptive filename
          const filename = `Zanzan_Academy_Certificate_${certificateData.certificateId}.pdf`
          pdf.save(filename)

          resolve(filename)
        })
        .catch((error) => {
          console.error("Error generating certificate:", error)
          reject(error)
        })
    })
  },

  // Print the certificate
  printCertificate: () => {
    window.print()
  },
}

// Export the CertificateGenerator object for use in other scripts
window.CertificateGenerator = CertificateGenerator
